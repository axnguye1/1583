Welcome to my platformer game.
The goal is to get to the exit without dying using your arrow keys. Space bar can also be used to jump, it's just preference. 
Good luck! 