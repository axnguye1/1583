Hello, Welcome user, to my short minigame. Your goal is to get your player safely to the police car waiting for you. Your goal is to not get caught by one of the infected traveling about.

instructions to play:
Use your w-a-s-d ( up- left - down- right) to control your player.
Your goal is to reach the police car and escape. If you come in contact with an infected, you will lose.
Details:
This game has minor graphics, running across a an empty street in the deserted city away from zombie characters to a police car. ( Graphics may not work for windows users). Will you make it?
